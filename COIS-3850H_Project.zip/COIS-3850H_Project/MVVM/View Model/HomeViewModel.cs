﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COIS_3850H_Project.MVVM.View_Model
{
    internal class HomeViewModel
    {
    }
}
